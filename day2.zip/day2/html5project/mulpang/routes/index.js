var express = require('express');
var router = express.Router();
var model = require('../model/mulpangDao');
var MyUtil = require('../utils/myutil');

/* GET home page. */
router.get('/', function(req, res, next) {
  //res.render('index.html', { title: '멀팡' });// index.ejs 파일을 의미
  res.redirect('/today');
});

// 쿠폰 목록 조회(오늘)
router.get('/today', function(req, res, next) { // /:변수이름 -> req.params.변수이름  으로 가져다 쓸 수 있음 
  model.couponList(function(list){
    res.render('today', { title: '오늘의 쿠폰',list:list});
  });
});

// 쿠폰 상세 조회
router.get('/coupons/:_id', function(req, res, next) { // /:변수이름 -> req.params.변수이름  으로 가져다 쓸 수 있음 
  model.couponDetail(req.params._id, function(coupon){
var myUtil = require('../utils/myutil');
    res.render('detail', { title: coupon.couponName, coupon, toStar: MyUtil.toStar}); // 변수명이랑 속성명이 동일하면 coupon:coupon 생략가능
  });
});

// 구매 화면
router.get('/purchases/:_id', function(req, res, next) { // /:변수이름 -> req.params.변수이름  으로 가져다 쓸 수 있음 
  model.buyCouponForm(req.params._id, function(coupon){
    res.render('buy', { title: coupon.couponName, coupon}); // 변수명이랑 속성명이 동일하면 coupon:coupon 생략가능
  });
});

// 구매 처리
router.post('/purchases', function(req, res, next) { // /:변수이름 -> req.params.변수이름  으로 가져다 쓸 수 있음 
  model.buyCoupon(req.body, function(err,result){ // post 방식이라 req body에 넘어옴 
    if(err){
      res.json({errors:err});
    }else{
      res.end('success');
    }
  });
});

router.get('/:page.html', function(req, res, next) { // /:변수이름 -> req.params.변수이름  으로 가져다 쓸 수 있음 
  res.render(req.params.page, { title: '오늘은 뭘파니? ' });
});

module.exports = router;

var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: '멀팡' });// index.ejs 파일을 의미
});

router.get('/:page.html', function(req, res, next) { // /:변수이름 -> req.params.변수이름  으로 가져다 쓸 수 있음 
  res.render(req.params.page, { title: '오늘은 뭘파니? ' });
});

module.exports = router;

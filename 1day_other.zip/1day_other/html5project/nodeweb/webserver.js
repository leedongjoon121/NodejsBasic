// 각각을 모듈이라 한다.
var http = require('http');
var fs = require('fs'); // 파일 시스템
var path = require('path'); // 경로
//var usrMime = require('./mimetypes'); // 사용자 정의 모듈
var mime = require('mime'); // 마임타입 알아서 찾아줌


var home = path.join(__dirname, 'design'); // 경로 결합 => 모듈 변수 , 전역변수 -> 절대경로 => / 로 이어줌

var server = http.createServer(function(req,res){
  var filename = req.url.substring(1); // / 빼고 파일 이름만
  
  if(filename == ''){ // localhost:1234 까지만 입력했을 때 
    filename = 'today.html';
  }
  //var mimeType = usrMime.myMime; // 실제로는 getMime
  var mimeType = mime.getType(filename);
  //비동기 방식
  fs.readFile(path.join(home, filename), function(err, data){ // 파일 읽고나서 콜백함수 호출 =>  항상 마지막 인자값, =>  실패,성공
    if(err){
      res.writeHead(404,{'Content-Type':'text/html;charset=utf-8'})
      res.end('<h1>'+filename+'파일을 찾을 수 없습니다.'+'</h1>');
    }else{
      res.writeHead(200,{'Content-Type': mimeType + ';charset=utf-8'})
      res.end(data);
    }
  });


  //동기방식 : readFileSync, 입출력 관련 파일 시스템만 주로 사용됨
  /*
  try{
    var data = fs.readFileSync(path.join(home,filename)); // 지정한 파일을 동기방식으로 읽어옴 , 절대경로 생성
    res.writeHead(200,{'Content-Type':'text/html;charset=utf-8'})
    res.end(data);
  }catch(err){
    res.writeHead(404,{'Content-Type':'text/html;charset=utf-8'})
    res.end('<h1>'+filename+'파일을 찾을 수 없습니다.'+'</h1>');
  }
  */

  
});

server.listen(1234, function(){
  console.log('HTTP 서버 구동 완료.');
});


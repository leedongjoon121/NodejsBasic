var path = require('path'); // 경로
// JavaScript Object Notation 
var mime = {
  "html" : "text/html",
  "css" : "text/css",
  "js" : "application.javascript",
  "svg" : "image/svg+xml"
};

// 확장자에 따른 mime 타입 리턴
function getMime(url){
   var extname = path.extname(url).substring(1); // 파일 확장자 꺼내줌, . 제거
   console.log("마임 타입 : "+extname);
   return mime[extname];
}

function getExtention(){

}

// mimetypes.js 파일 중 내보낼 값 
//module.exports = getMime; 

module.exports = {
  myMime: getMime,
  myExt : getExtention
};

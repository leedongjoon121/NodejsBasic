var express = require('express');
var router = express.Router();
var model = require('../model/mulpangDao');
var MyUtil = require('../utils/myutil');
var checklogin = require('../middleware/checklogin');

/* GET home page. */
router.get('/', function(req, res, next) {
  //res.render('index.html', { title: '멀팡' });// index.ejs 파일을 의미
  res.redirect('/today');
});

// 쿠폰 목록 조회(오늘)
router.get('/today', function(req, res, next) { // /:변수이름 -> req.params.변수이름  으로 가져다 쓸 수 있음 
    if(req.query.page){
      req.query.page = parseInt(req.query.page);
    }else{ // 페이징 처리 없으면 1페이지에서 시작 
      req.query.page = 1;
      if(req.query.date){ req.url += '&page=1'; }else{ req.url += '?page=1';} // 다른 쿼리스트링 있으면 &만 붙이고, 없으면 ? 붙여서 시작
    }
    model.couponList(req.query, function(list){
    list.page = {};
    if(req.query.page > 1){ // 이전페이지 있으면 
      list.page.pre = req.url.replace(`page=${req.query.page}`, `page=${req.query.page-1}`);
    }
    if(req.query.page < list.totalPage){ // 다음페이지가 있을 경우
      list.page.next = req.url.replace(`page=${req.query.page}`, `page=${req.query.page+1}`);
    }
    res.render('today', { title: '오늘의 쿠폰',list:list, options:MyUtil.generateOptions, query:req.query  ,css:'today.css'});
  });
});

// 쿠폰 상세 조회
router.get('/coupons/:_id', function(req, res, next) { // /:변수이름 -> req.params.변수이름  으로 가져다 쓸 수 있음 
  model.couponDetail(req.app.get('socketio'), req.params._id, function(coupon){
 //   var myUtil = require('../utils/myutil');
    res.render('detail', { title: coupon.couponName, coupon
                        , toStar: MyUtil.toStar
                        , css:'detail.css'
                        , js:'detail.js'}); // 변수명이랑 속성명이 동일하면 coupon:coupon 생략가능
  });
});

// 구매 화면
router.get('/purchases/:_id', checklogin, function(req, res, next) { // /:변수이름 -> req.params.변수이름  으로 가져다 쓸 수 있음 
  // var user = req.session.user;
  // if(user){
    model.buyCouponForm(req.params._id, function(coupon){
    res.render('buy', { title: coupon.couponName, coupon, css: 'detail.css', js:'buy.js'}); // 변수명이랑 속성명이 동일하면 coupon:coupon 생략가능
    });
  // }else{
  //   req.session.backurl = req.originalUrl;
  //   res.redirect('/users/login');
  // } 
});

// 구매 처리
router.post('/purchases', checklogin, function(req, res, next) { // /:변수이름 -> req.params.변수이름  으로 가져다 쓸 수 있음 
  // var user = req.session.user;
  // if(user){
    req.body.email = req.session.user._id;
    model.buyCoupon(req.body, function(err,result){ // post 방식이라 req body에 넘어옴 
      if(err){
        // res.json({errors:err});
        next(err);
      }else{
        res.end('success');
      }
    });
  // }else{
  //   res.json({errors:{message:'로그인 후 구매가능합니다.'}});
  // }

});

// 근처 메뉴
router.get('/location', function(req, res, next){
  model.couponList(null, function(list){
    res.render('location', {title: '근처 쿠폰', list, css: 'location.css', js: 'location.js'});
  });
  
});
// 추천 메뉴
router.get('/best', function(req, res, next){
  res.render('best', {title: '추천 쿠폰', css: 'best.css', js: 'best.js'});
});
// top5 쿠폰 조회
router.get('/topCoupon', function(req, res, next){
  model.topCoupon(req.query.condition, function(list){
    res.json(list);
  });
});
// 모두 메뉴
router.get('/all', function(req, res, next){
  model.couponList(req.query, function(list){
    res.render('all', { title: '모든 쿠폰',list:list, options:MyUtil.generateOptions, query:req.query ,css:'all.css'});
  });
});
// 쿠폰 남은 수량 조회
router.get('/couponQuantity', function(req, res, next){
  var idList = req.query.couponIdList.split(',');
  model.couponQuantity(idList,function(list){
    res.contentType('text/event-stream');
    res.write('data:'+JSON.stringify(list)+'\n');
    res.write('retry: 10000\n');
    res.end('\n');
  });
  
});

// router.get('/:page.html', function(req, res, next) { // /:변수이름 -> req.params.변수이름  으로 가져다 쓸 수 있음 
//   res.render(req.params.page, { title: '오늘은 뭘파니? ' });
// });

module.exports = router;

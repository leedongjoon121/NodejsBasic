$(function(){ // 최초 한번 등록해놓음
	setCancelEvent();
	setBuyEvent();
	setPriceEvent();	
});

// 취소 버튼 클릭
function setCancelEvent(){
	$('form button[type=reset]').on('click',function(){
    window.history.back();
  }); // 타입이 리셋인 버튼
}

// 구매 버튼 클릭
function setBuyEvent(){
	$('.detail form').on('submit',function(){
    var body = $(this).serialize(); // 폼 테그의 모든 입력 요소의 값을 쿼리스트링 (네임 벨류) 쌍으로 반환 해줌
    $.ajax({
      url:'/purchases',
      method:'post',
      data:body,
      success:function(result){
        if(result.errors){
          alert(result.errors.message);
        }else{
          alert('쿠폰 구매가 완료되었습니다.');
          window.location.href = '/'; // 구매 완료되면 메인 페이지로 이동 
        }
      }
    }); 
    return false;
  });
}

// 구매수량 수정시 결제가격 계산
function setPriceEvent(){
	$("input[name=quantity]").on('change',function(){
    $('output[name=totalPrice]').text( $(this).val()*$('input[name=unitPrice]').val()  );
  });
}